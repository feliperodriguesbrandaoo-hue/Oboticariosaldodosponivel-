
import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-[#006341] overflow-hidden">
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <rect width="100" height="100" fill="url(#grid)" />
          <defs>
            <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
        </svg>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center bg-yellow-400 text-green-900 px-4 py-2 rounded-full text-xs font-black shadow-2xl animate-pulse">
              <span className="mr-2">🔥</span> LOTE DE SALDO LIBERADO: 98% PREENCHIDO
            </div>
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black text-white leading-[0.95] tracking-tighter">
              COMPRE TUDO COM O <span className="text-yellow-400">NOSSO SALDO</span>.
            </h1>
            <p className="text-xl lg:text-2xl text-white/90 max-w-xl leading-relaxed font-bold">
              Ativamos um esquema de <span className="underline decoration-yellow-400 decoration-4">Capital de Giro Imediato</span> no seu painel. Você escolhe os produtos e lucra sem tirar um real do bolso.
            </p>
            <div className="flex flex-col sm:flex-row gap-5 pt-4">
              <a href="#cadastro" className="bg-yellow-400 text-green-900 px-10 py-6 rounded-2xl font-black text-xl text-center hover:bg-yellow-300 transition-all shadow-xl transform hover:-translate-y-1 uppercase tracking-tight">Ativar Meu Saldo Agora</a>
            </div>
          </div>
          
          <div className="hidden lg:block relative">
            <div className="relative bg-white p-10 rounded-[3rem] shadow-2xl border-4 border-yellow-400 transform rotate-2">
              <div className="flex justify-between items-center mb-8">
                <span className="text-gray-400 font-black text-[10px] uppercase tracking-widest">Painel de Crédito Central</span>
                <span className="bg-green-100 text-green-600 px-2 py-1 rounded text-xs font-bold">✓ Verificado</span>
              </div>
              <div className="space-y-6">
                <div>
                  <p className="text-gray-400 text-xs font-bold uppercase mb-1">Margem Disponível</p>
                  <p className="text-7xl font-black text-green-800 tracking-tighter">R$ 9.500</p>
                </div>
                <div className="bg-green-50 p-6 rounded-2xl border border-green-100">
                  <p className="text-green-800 font-bold">LIBERAÇÃO AUTOMÁTICA HABILITADA ✓</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
