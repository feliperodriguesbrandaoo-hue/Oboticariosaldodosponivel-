
import React from 'react';

interface HeaderProps {
  onToggleDashboard: () => void;
}

const Header: React.FC<HeaderProps> = ({ onToggleDashboard }) => {
  return (
    <nav className="bg-white border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center space-x-2">
            <div className="bg-boticario-green p-2 rounded-lg">
              <span className="text-white font-bold text-xl tracking-tighter">B</span>
            </div>
            <span className="text-2xl font-semibold text-boticario-green tracking-tight">
              O Boticário <span className="text-gray-400 font-light text-sm ml-2 hidden sm:inline">Revenda Oficial</span>
            </span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="#beneficios" className="text-gray-600 hover:text-boticario-green font-medium transition-colors">Benefícios</a>
            <a href="#cadastro" className="bg-boticario-green text-white px-6 py-2 rounded-full font-semibold hover:bg-opacity-90 transition-all shadow-md">Quero meu limite</a>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Header;
