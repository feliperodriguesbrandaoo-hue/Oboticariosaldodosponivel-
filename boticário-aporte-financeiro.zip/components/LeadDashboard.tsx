
import React from 'react';
import { Lead } from '../types';

interface LeadDashboardProps {
  leads: Lead[];
  onClear: () => void;
}

const LeadDashboard: React.FC<LeadDashboardProps> = ({ leads, onClear }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12 animate-fade-in">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-4xl font-black text-green-900 uppercase">Gestão de Leads</h2>
        <button onClick={onClear} className="bg-red-50 text-red-600 px-6 py-2 rounded-xl font-bold hover:bg-red-100 transition-colors">Zerar Base de Dados</button>
      </div>
      
      {leads.length === 0 ? (
        <div className="bg-gray-50 border-2 border-dashed border-gray-200 rounded-[2.5rem] p-20 text-center">
          <p className="text-gray-400 font-bold text-xl uppercase tracking-widest">Nenhum cadastro recebido ainda.</p>
        </div>
      ) : (
        <div className="bg-white rounded-[2.5rem] shadow-2xl border border-gray-100 overflow-hidden">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="px-8 py-6 font-black text-xs uppercase tracking-widest text-gray-500">Data/Hora</th>
                <th className="px-8 py-6 font-black text-xs uppercase tracking-widest text-gray-500">Nome Completo</th>
                <th className="px-8 py-6 font-black text-xs uppercase tracking-widest text-gray-500">CPF / E-mail</th>
                <th className="px-8 py-6 font-black text-xs uppercase tracking-widest text-gray-500">WhatsApp</th>
                <th className="px-8 py-6 font-black text-xs uppercase tracking-widest text-gray-500">Saldo Aprovado</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((lead) => (
                <tr key={lead.id} className="border-b border-gray-50 hover:bg-green-50/30 transition-colors">
                  <td className="px-8 py-6">
                    <p className="text-sm font-bold">{new Date(lead.submittedAt).toLocaleDateString()}</p>
                    <p className="text-[10px] text-gray-400">{new Date(lead.submittedAt).toLocaleTimeString()}</p>
                  </td>
                  <td className="px-8 py-6">
                    <p className="font-black text-gray-900">{lead.fullName}</p>
                  </td>
                  <td className="px-8 py-6">
                    <p className="text-sm font-bold text-gray-600">{lead.cpf}</p>
                    <p className="text-xs text-gray-400">{lead.email}</p>
                  </td>
                  <td className="px-8 py-6 font-bold text-sm">{lead.phone}</td>
                  <td className="px-8 py-6">
                    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-black">
                      R$ {lead.approvedLimit?.toLocaleString('pt-BR')}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default LeadDashboard;
