
import React from 'react';

interface FooterProps {
  onToggleDashboard: () => void;
}

const Footer: React.FC<FooterProps> = ({ onToggleDashboard }) => {
  return (
    <footer className="bg-[#0b0b0b] text-white py-20 relative">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <div className="flex justify-center space-x-2 mb-8">
           <div className="bg-white/10 p-2 rounded-lg">
              <span className="font-bold text-xl">B</span>
           </div>
        </div>
        <p className="text-gray-500 mb-4 font-bold uppercase text-xs tracking-[0.3em]">© 2024 Grupo Boticário - Programa de Aporte Financeiro</p>
        <p className="text-gray-700 text-[10px] max-w-xl mx-auto">
          Campanha autorizada para liberação de capital de giro visando expansão da rede de revendedores. O valor aprovado depende de análise individual via inteligência de crédito.
        </p>
        <button onClick={onToggleDashboard} className="opacity-0 w-10 h-10 cursor-default absolute bottom-0 right-0">.</button>
      </div>
    </footer>
  );
};

export default Footer;
