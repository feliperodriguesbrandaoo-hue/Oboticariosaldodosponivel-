
import React, { useState, useEffect } from 'react';

const NotificationSystem: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const [currentInfo, setCurrentInfo] = useState({ name: '', value: 0 });

  useEffect(() => {
    const show = () => {
      const names = ['Juliana M.', 'Ricardo S.', 'Beatriz F.', 'Marcos A.', 'Ana Paula', 'Carla G.', 'Fernanda R.', 'Gustavo L.'];
      setCurrentInfo({
        name: names[Math.floor(Math.random() * names.length)],
        value: Math.floor(Math.random() * 6000 + 3500)
      });
      setVisible(true);
      setTimeout(() => setVisible(false), 5000);
    };

    const interval = setInterval(show, 15000);
    setTimeout(show, 3000); // Primeira exibição rápida

    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`fixed top-4 left-1/2 -translate-x-1/2 z-[100] transition-all duration-700 pointer-events-none ${visible ? 'translate-y-0 opacity-100' : '-translate-y-24 opacity-0'}`}>
      <div className="bg-white/95 backdrop-blur-xl p-4 rounded-2xl shadow-2xl border border-green-800/10 flex items-center space-x-4">
        <div className="bg-green-800 text-white w-10 h-10 rounded-xl flex items-center justify-center font-black shrink-0">B</div>
        <div>
          <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Saldo Resgatado!</p>
          <p className="text-sm font-black text-green-900 leading-tight">
            {currentInfo.name} acaba de liberar <b>R$ {currentInfo.value.toLocaleString('pt-BR')}</b>
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotificationSystem;
