
import React from 'react';

const Benefits: React.FC = () => {
  return (
    <section id="beneficios" className="bg-gray-50 py-24">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <h2 className="text-4xl font-black text-green-900 uppercase mb-16">O Fim das Barreiras para Revender</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { title: "Saldo em Painel", icon: "💳", desc: "Aporte financeiro injetado no seu login." },
            { title: "Zero Desembolso", icon: "🆓", desc: "Compre produtos sem usar seu salário." },
            { title: "Autofinanciamento", icon: "📈", desc: "Pague o saldo com o lucro das vendas." },
            { title: "Aprovação em Minutos", icon: "⚡", desc: "Fundo de reserva aprovado via CPF." }
          ].map((b, i) => (
            <div key={i} className="p-10 rounded-[2.5rem] bg-white shadow-xl border border-gray-100 hover:scale-105 transition-transform">
              <div className="text-5xl mb-6">{b.icon}</div>
              <h3 className="text-xl font-black text-gray-900 mb-2 uppercase tracking-tighter">{b.title}</h3>
              <p className="text-gray-500 font-bold text-sm">{b.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Benefits;
