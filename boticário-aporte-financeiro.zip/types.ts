
export interface Lead {
  id: string;
  fullName: string;
  email: string;
  cpf: string;
  phone: string;
  birthDate: string;
  submittedAt: string;
  status: 'pending' | 'analyzing' | 'approved';
  approvedLimit?: number;
}

export enum FormStep {
  INITIAL = 'INITIAL',
  ANALYZING = 'ANALYZING',
  SUCCESS = 'SUCCESS'
}
