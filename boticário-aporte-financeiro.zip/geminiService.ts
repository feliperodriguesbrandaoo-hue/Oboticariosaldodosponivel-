
import { GoogleGenAI, Type } from "@google/genai";

export const analyzeCreditProfile = async (name: string, cpf: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analise o perfil para liberação de SALDO EM PAINEL para o novo revendedor chamado ${name} (CPF: ${cpf}). 
      Gere um valor de limite de crédito entre R$ 3.800,00 e R$ 9.500,00.
      Crie também uma mensagem curta, MUITO PERSUASIVA e motivacional, confirmando que o saldo já está disponível.
      Foque na ideia de "comprar produtos sem precisar de dinheiro próprio".`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            suggestedLimit: { type: Type.NUMBER },
            message: { type: Type.STRING }
          },
          required: ["suggestedLimit", "message"]
        }
      }
    });

    return JSON.parse(response.text || '{"suggestedLimit": 4500, "message": "Aprovação imediata detectada!"}');
  } catch (error) {
    console.error("Error analyzing profile:", error);
    return {
      suggestedLimit: 3200 + Math.floor(Math.random() * 2000),
      message: "Incrível! Detectamos uma margem de confiança alta no seu CPF. Seu saldo já foi pré-alocado no sistema."
    };
  }
};
