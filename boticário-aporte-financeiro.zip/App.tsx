
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ApplicationForm from './components/ApplicationForm';
import Benefits from './components/Benefits';
import Footer from './components/Footer';
import LeadDashboard from './components/LeadDashboard';
import NotificationSystem from './components/NotificationSystem';
import { Lead } from './types';

const App: React.FC = () => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [showDashboard, setShowDashboard] = useState(false);

  useEffect(() => {
    const savedLeads = localStorage.getItem('boticario_leads');
    if (savedLeads) {
      setLeads(JSON.parse(savedLeads));
    }
  }, []);

  const handleNewLead = (newLead: Lead) => {
    const updatedLeads = [newLead, ...leads];
    setLeads(updatedLeads);
    localStorage.setItem('boticario_leads', JSON.stringify(updatedLeads));
  };

  const clearLeads = () => {
    setLeads([]);
    localStorage.removeItem('boticario_leads');
  };

  const toggleDashboard = () => setShowDashboard(!showDashboard);

  return (
    <div className="min-h-screen flex flex-col bg-white overflow-x-hidden">
      <NotificationSystem />
      <Header onToggleDashboard={toggleDashboard} />
      
      {showDashboard ? (
        <LeadDashboard leads={leads} onClear={clearLeads} />
      ) : (
        <main className="flex-grow">
          <Hero />
          
          <div className="bg-black text-yellow-400 py-6 overflow-hidden whitespace-nowrap shadow-2xl border-y-4 border-yellow-400">
             <div className="flex space-x-12 animate-marquee font-black uppercase text-sm tracking-widest">
                <span>Saldo Imediato em Painel</span>
                <span>•</span>
                <span>Esquema de Capital Zero</span>
                <span>•</span>
                <span>Compre sem gastar seu dinheiro</span>
                <span>•</span>
                <span>Até R$ 9.500 de Aporte</span>
                <span>•</span>
                <span>Aprovação via CPF na Hora</span>
                <span>•</span>
                <span>Lucro 100% livre no bolso</span>
                <span>•</span>
                <span>Revenda Oficial Boticário</span>
             </div>
          </div>

          <div id="cadastro" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-36">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
              <div className="space-y-12">
                <div className="space-y-6">
                  <h2 className="text-6xl lg:text-7xl font-black text-green-900 leading-[0.9] uppercase tracking-tighter">
                    O SEGREDO<br/>DO SALDO<br/>LIBERADO.
                  </h2>
                  <p className="text-2xl text-gray-500 font-bold leading-relaxed">
                    Não somos apenas revenda. Somos um <span className="text-green-800 font-black underline decoration-green-800 underline-offset-8">esquema inteligente de aporte</span>. Nós fornecemos o capital, você fornece a vontade de vencer.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                  {[
                    { title: "Limite de Aporte", text: "Saldo real injetado no seu login de revendedor." },
                    { title: "Zero Burocracia", text: "Não precisa de fiador nem comprovação de renda." },
                    { title: "Estoque Infinito", text: "Use o saldo para repor produtos sempre que vender." },
                    { title: "Pague com Lucro", text: "Você só repõe o saldo após receber dos seus clientes." }
                  ].map((item, idx) => (
                    <div key={idx} className="bg-gray-50 p-8 rounded-[2rem] border-2 border-gray-100 hover:border-green-800 transition-all group">
                        <h4 className="text-xl font-black text-gray-900 uppercase tracking-tight mb-2 group-hover:text-green-800">{item.title}</h4>
                        <p className="text-gray-500 font-bold text-sm leading-snug">{item.text}</p>
                    </div>
                  ))}
                </div>

                <div className="p-10 bg-green-900 rounded-[3rem] text-white flex items-center space-x-8 shadow-2xl relative overflow-hidden border-4 border-green-800">
                   <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-400 opacity-10 rounded-full -mr-16 -mt-16"></div>
                   <div className="bg-yellow-400 p-5 rounded-3xl text-3xl shadow-lg">⚡</div>
                   <div>
                      <p className="text-2xl font-black uppercase leading-tight tracking-tight">Vagas Limitadas</p>
                      <p className="text-white/70 font-bold mt-1">Este lote de saldo grande encerra hoje às 23:59.</p>
                   </div>
                </div>
              </div>
              
              <div className="relative">
                <div className="absolute -inset-8 bg-gray-50 rounded-[4rem] transform -rotate-2"></div>
                <div className="relative bg-white rounded-[3.5rem] shadow-[0_50px_100px_rgba(0,0,0,0.1)] p-12 border-2 border-gray-100">
                  <ApplicationForm onLeadCapture={handleNewLead} />
                </div>
              </div>
            </div>
          </div>
          <Benefits />
        </main>
      )}

      <Footer onToggleDashboard={toggleDashboard} />
      
      <style>{`
        @keyframes bounce-slow {
          0%, 100% { transform: translateY(-10%); }
          50% { transform: translateY(0); }
        }
        .animate-bounce-slow {
          animation: bounce-slow 4s ease-in-out infinite;
        }
        .animate-fade-in {
          animation: fadeIn 0.8s ease-out forwards;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default App;
